
# JUDE Global Team – Copywriting Repository

Welcome to the official GitHub repository for JUDE Global Team.  
Here you'll find professional development resources, writing samples, and guides.

## Included Resources

- [Fundamentals of Copywriting (PDF)](./Fundamentals%20of%20Copywriting%20.pdf)

## About

This repository is maintained by Jude Ojiabu as part of an ongoing professional development and copywriting portfolio.
